# QA Bot — Android App

Savol va javob kiritib Telegram botga yuboruvchi ilova.

## Ishlatish
1. Ilovani oching
2. Savol kiriting
3. Javob kiriting
4. "Davom etish" tugmasini bosing → Telegram ga yuboriladi

## Build
Android Studio → Open → qabot → Build APK
